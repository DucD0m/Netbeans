/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdom;

import java.util.List;
import org.jdom2.*;

/**
 *
 * @author domup
 */
public class Modele { // Partie Modèle du MVC.
    
    private Document doc;
    private Element rootNode;
    private Element channelNode;
    private List liste;
    
    protected Document getDocument() {
        return doc;
    }

    protected void setDocument(Document doc) {
        this.doc = doc;
    }
    
    // Liste de noeuds item JDOM.
    protected List getListe (){
         rootNode = doc.getRootElement();
         channelNode = rootNode.getChild("channel");
         liste = channelNode.getChildren("item");
         return liste;
    }
}
