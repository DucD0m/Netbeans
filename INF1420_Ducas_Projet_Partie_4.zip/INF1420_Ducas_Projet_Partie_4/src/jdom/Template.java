/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdom;

import org.jdom2.Document;

/**
 *
 * @author domup
 */
public abstract class Template {
   
    protected abstract Document getUrlDocument();
    protected abstract Document getPathDocument(String path);
    protected abstract void enregistrerFichier(Document d, String s);
}
