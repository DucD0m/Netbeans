/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdom;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import org.jdom2.*;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

/**
 *
 * @author domup
 */

// Partie Contrôleur du MVC.
public class Controller extends Template implements Command, Observer {
    
    private Document doc;
    private SAXBuilder builder = new SAXBuilder();
    protected ArrayList <Document> docList = new ArrayList(); // Liste pour les modifications à un document.
    protected int docCompteur;      // Compteur pour suivre la position d'une modification dans la liste docList.
    private String path;            // Variable qui reçoit l'emplacement d'un fichier sur l'ordinateur.
    
    // Méthode set pour assigner le document au contrôleur.
    protected void setDocument(Document doc, String path){
        this.doc = doc;
        this.path = path;
    }
    
    @Override // Template
    protected Document getUrlDocument(){    // Génère un document depuis un fil RSS sur internet.
        
        try{
            String url = "https://www.teluq.ca/site/infos/rss/communiques.php";
            doc = builder.build(url);
        }
        
        catch(IOException | JDOMException e) {
            System.out.println("URL invalide");
            System.exit(-1);
       }
        return doc;
    }
    
    @Override // Template
    protected Document getPathDocument(String path){    // Génère un document depuis un fichier sur l'ordinateur.
        
        try{
            File filename = new File(path);
            doc = builder.build(filename);
        }
        
        catch(IOException | JDOMException e) {
            System.out.println("Fichier .xml invalide");
            System.exit(-1);
       }
        return doc;
    }
    
    @Override // Template
    protected void enregistrerFichier(Document d, String s){ // Enregistre un fichier sur l'ordinateur.
        try{
        XMLOutputter outputter = new XMLOutputter();
        outputter.setFormat(Format.getPrettyFormat());
        outputter.output(d, new OutputStreamWriter(new FileOutputStream(new File(s)),"UTF-8"));
        }

        catch (IOException io){
            System.out.println("Problème lors de l'enregistrement du fichier");
            System.exit(-1);
        }
        
        // Pour les notifications Observer.
        notifyAjouter("L'événement a été ajouté avec succès");
        notifyModifier("L'événement a été modifié avec succès");
        notifyAnnuler("La dernière modification a été annulée avec succès");
    }
    
    @Override // Command
    public void annuler(){  // Méthode pour les boutons Annuler la dernière modification dans la vue (classe Bouton).
        enregistrerFichier(doc, path);
        if (docCompteur > 0){
            docCompteur--;
        }
    }
    
    @Override // Command
    public void refaire(){
        //Cette fonction n'est pas prévue dans le projet.
    }
    
    @Override // Observer
    public void notifyAjouter(String message){
        Bouton.messageAjouter(message); // Envoie le message reçu en argument à la vue.
    }
    
    @Override // Observer
    public void notifyModifier(String message){
        Bouton.messageModifier(message);
    }
    
    @Override // Observer
    public void notifyAnnuler(String message){
        Bouton.messageAnnuler(message);
    }
}
