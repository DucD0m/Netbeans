/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jdom;

import java.io.IOException;
import java.io.*;
import java.util.List;
import org.jdom2.*;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

/**
 *
 * @author domup
 */

// Partie Vue du MVC. Je n'ai pas été capable de changer le nom de cette classe après avoir terminé le projet.
// Les recommendations des parties 2 et 3 du projet on été appliquées sauf pour la taille des jCheckBox. 
// Les onglets Visualiser événement et Retirer événement n'ont pas été permutés.
public class Bouton extends javax.swing.JFrame implements Composite {

    private Modele url = new Modele();
    private Modele path = new Modele();
    private Controller controller = new Controller();
    
    private List internet;
    private List fichier;
    
    private Element itemNode;
    
    private static String messageAjoutEvenement;
    private static String messageModifieEvenement;
    private static String messageAnnulerEvenement;
    
    /** Creates new form Bouton */
    private Bouton() {
        
        initComponents();
        
        // Récupère le fil RSS et affiche les événements dans les boutons sous l'onglet
        // Consulter sur internet
        url.setDocument(controller.getUrlDocument());
        internet = url.getListe();
        jButton1.setText(((Element) internet.get(0)).getChildText("title"));
        jButton2.setText(((Element) internet.get(1)).getChildText("title"));
        jButton3.setText(((Element) internet.get(2)).getChildText("title"));
        jButton4.setText(((Element) internet.get(3)).getChildText("title"));
        jButton5.setText(((Element) internet.get(4)).getChildText("title"));
        jButton6.setText(((Element) internet.get(5)).getChildText("title"));
        jButton7.setText(((Element) internet.get(6)).getChildText("title"));
        jButton8.setText(((Element) internet.get(7)).getChildText("title"));
        jButton9.setText(((Element) internet.get(8)).getChildText("title"));
        jButton10.setText(((Element) internet.get(9)).getChildText("title"));
        jButton11.setText(((Element) internet.get(10)).getChildText("title"));
        jButton12.setText(((Element) internet.get(11)).getChildText("title"));
        jButton13.setText(((Element) internet.get(12)).getChildText("title"));
        jButton14.setText(((Element) internet.get(13)).getChildText("title"));
        jButton15.setText(((Element) internet.get(14)).getChildText("title"));
        
        // Cache le jTextArea dans les onglets Ajouter un événement et Modifier un événement 
        evenementOff();
    }
 
    // Pour ouvrir un événement RSS dans un fureteur web.
    private void consulterURL(int pos){
        
        try{
          itemNode = (Element) internet.get(pos);
          String lien = itemNode.getChildText("link");
          java.awt.Desktop.getDesktop().browse(java.net.URI.create(lien)); 
        }
        
        catch (IOException ex){
            System.out.println("Incapable d'ouvrir le flux RSS");
            System.exit(-1);        
        }
    }
    
    // Affiche les événements dans l'onglet Visualiser un événement
    private void setVisualiser(){
        if (fichier.size()<1) {jButton20.setText("");} else{jButton20.setText(((Element) fichier.get(0)).getChildText("title"));}
        if (fichier.size()<2) {jButton21.setText("");} else{jButton21.setText(((Element) fichier.get(1)).getChildText("title"));}
        if (fichier.size()<3) {jButton22.setText("");} else{jButton22.setText(((Element) fichier.get(2)).getChildText("title"));}
        if (fichier.size()<4) {jButton23.setText("");} else{jButton23.setText(((Element) fichier.get(3)).getChildText("title"));}
        if (fichier.size()<5) {jButton24.setText("");} else{jButton24.setText(((Element) fichier.get(4)).getChildText("title"));}
        if (fichier.size()<6) {jButton25.setText("");} else{jButton25.setText(((Element) fichier.get(5)).getChildText("title"));}
        if (fichier.size()<7) {jButton26.setText("");} else{jButton26.setText(((Element) fichier.get(6)).getChildText("title"));}
        if (fichier.size()<8) {jButton27.setText("");} else{jButton27.setText(((Element) fichier.get(7)).getChildText("title"));}
        if (fichier.size()<9) {jButton28.setText("");} else{jButton28.setText(((Element) fichier.get(8)).getChildText("title"));}
        if (fichier.size()<10) {jButton29.setText("");} else{jButton29.setText(((Element) fichier.get(9)).getChildText("title"));}
        if (fichier.size()<11) {jButton30.setText("");} else{jButton30.setText(((Element) fichier.get(10)).getChildText("title"));}
        if (fichier.size()<12) {jButton31.setText("");} else{jButton31.setText(((Element) fichier.get(11)).getChildText("title"));}
        if (fichier.size()<13) {jButton32.setText("");} else{jButton32.setText(((Element) fichier.get(12)).getChildText("title"));}
        if (fichier.size()<14) {jButton33.setText("");} else{jButton33.setText(((Element) fichier.get(13)).getChildText("title"));}
        if (fichier.size()<15) {jButton34.setText("");} else{jButton34.setText(((Element) fichier.get(14)).getChildText("title"));}
        if (fichier.size()<16) {jButton35.setText("");} else{jButton35.setText(((Element) fichier.get(15)).getChildText("title"));}
    }
    
    // Affiche le noeud item d'un événement dans le jTextArea de l'onglet Visualiser un événement
    private void setVisualiserTexteArea(int pos){
        if (fichier.size()< (pos+1)){ // Si le bouton choisi représente une position qui n'existe pas.
            jTextArea1.setText("Aucun événement à afficher.");
        }
        else {
            jTextArea1.setText(new XMLOutputter().outputString((Element) fichier.get(pos)));
        }
    }
    
    // Pour déterminer les positions du jComboBox de l'onglet Modifier un événement.
    private String setModel(int pos){
        
        if (fichier.size()<(pos+1)){
            return ""; // S'il n'y a pas de noeud item pour la position.
        } 
                    
        else { // Assigne le titre du noeud item.
            return ((Element) fichier.get(pos)).getChildText("title");
        }
    }
    
    // Définition du modèle du jComboBox de l'onglet Modifier un événement.
    private void setModifier(){
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {setModel(0), 
                setModel(1), 
                setModel(2), 
                setModel(3), 
                setModel(4), 
                setModel(5), 
                setModel(6), 
                setModel(7), 
                setModel(8), 
                setModel(9), 
                setModel(10), 
                setModel(11), 
                setModel(12),
                setModel(13),
                setModel(14),
                setModel(15), 
                setModel(16)}));
    }
    
    // Affiche les information du noeud item dans les jTextFields pour une meilleur expérience utilisateur 
    // selon les recommendations de la partie 3 du projet.
    private void setModifierChamps(){
        jTextField1.setText(((Element) fichier.get(jComboBox1.getSelectedIndex())).getChildText("title"));
        jTextField2.setText(((Element) fichier.get(jComboBox1.getSelectedIndex())).getChildText("link"));
        jTextField3.setText(((Element) fichier.get(jComboBox1.getSelectedIndex())).getChildText("pubDate"));
        jTextField4.setText(((Element) fichier.get(jComboBox1.getSelectedIndex())).getChildText("description"));
    }
    
    // Affiche les événements dans l'onglet Retirer un événement.
    private void setRetirer(){
      if (fichier.size()<1) {jLabel3.setText("");} else{jLabel3.setText(((Element) fichier.get(0)).getChildText("title"));}
      if (fichier.size()<2) {jLabel4.setText("");} else{jLabel4.setText(((Element) fichier.get(1)).getChildText("title"));}
      if (fichier.size()<3) {jLabel5.setText("");} else{jLabel5.setText(((Element) fichier.get(2)).getChildText("title"));}
      if (fichier.size()<4) {jLabel6.setText("");} else{jLabel6.setText(((Element) fichier.get(3)).getChildText("title"));}
      if (fichier.size()<5) {jLabel7.setText("");} else{jLabel7.setText(((Element) fichier.get(4)).getChildText("title"));}
      if (fichier.size()<6) {jLabel8.setText("");} else{jLabel8.setText(((Element) fichier.get(5)).getChildText("title"));}
      if (fichier.size()<7) {jLabel9.setText("");} else{jLabel9.setText(((Element) fichier.get(6)).getChildText("title"));}
      if (fichier.size()<8) {jLabel10.setText("");} else{jLabel10.setText(((Element) fichier.get(7)).getChildText("title"));}
      if (fichier.size()<9) {jLabel11.setText("");} else{jLabel11.setText(((Element) fichier.get(8)).getChildText("title"));}
      if (fichier.size()<10) {jLabel12.setText("");} else{jLabel12.setText(((Element) fichier.get(9)).getChildText("title"));}
      if (fichier.size()<11) {jLabel13.setText("");} else{jLabel13.setText(((Element) fichier.get(10)).getChildText("title"));}
      if (fichier.size()<12) {jLabel14.setText("");} else{jLabel14.setText(((Element) fichier.get(11)).getChildText("title"));}
      if (fichier.size()<13) {jLabel15.setText("");} else{jLabel15.setText(((Element) fichier.get(12)).getChildText("title"));}
      if (fichier.size()<14) {jLabel16.setText("");} else{jLabel16.setText(((Element) fichier.get(13)).getChildText("title"));}
      if (fichier.size()<15) {jLabel17.setText("");} else{jLabel17.setText(((Element) fichier.get(14)).getChildText("title"));}
      if (fichier.size()<16) {jLabel18.setText("");} else{jLabel18.setText(((Element) fichier.get(15)).getChildText("title"));}
    }
    
    // Affiche le jTextArea et le jLabel des onglets Ajouter un événement et Modifier un événement
    @Override // Patron Composite
    public void evenementOn(){
        jScrollPane3.setVisible(true);
        jLabel29.setVisible(true);
        jScrollPane4.setVisible(true);
        jLabel30.setVisible(true);
    }
    
    // Masque les mêmes composantes
    @Override //Patron Composite
    public void evenementOff(){
        jScrollPane3.setVisible(false);
        jLabel29.setVisible(false);
        jScrollPane4.setVisible(false);
        jLabel30.setVisible(false);
    }
    
    // Méthode pour préparer l'enregistrement dans un fichier et charger docList pour la fonction Annuler.
    private void setEnregistrer(){
        path.setDocument(controller.getPathDocument(jLabel2.getText()));
        controller.enregistrerFichier(path.getDocument(), "temporaire.xml");
        Document temporaire = controller.getPathDocument("temporaire.xml");
        controller.docList.add(controller.docCompteur, temporaire);
        controller.docCompteur++;
        fichier = path.getListe();
    }
    
    // Méthode pour préparer l'annulation de modifications et son enregistrement dans un fichier.
    private void setAnnuler(){
        path.setDocument(controller.docList.get(controller.docCompteur-1));
        fichier = path.getListe();
        controller.setDocument(path.getDocument(), jLabel2.getText());
        controller.annuler();

        setRetirer();
        setVisualiser();
        setModifier();
        evenementOff();
    }
    
    // Méthodes pour la notification depuis le controlleur vers la vue.
    // Recommendation de la partie 2 du projet.
    protected static void messageAjouter(String message){
        messageAjoutEvenement = message;
    }
    
    protected static void messageModifier(String message){
        messageModifieEvenement = message;
    }
    
    protected static void messageAnnuler(String message){
        messageAnnulerEvenement = message;
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFileChooser1 = new javax.swing.JFileChooser();
        jOptionPane1 = new javax.swing.JOptionPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton40 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton19 = new javax.swing.JButton();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel11 = new javax.swing.JPanel();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        jButton34 = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jButton38 = new javax.swing.JButton();
        jButton39 = new javax.swing.JButton();
        jLabel27 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel29 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jButton36 = new javax.swing.JButton();
        jButton37 = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jLabel30 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jCheckBox7 = new javax.swing.JCheckBox();
        jCheckBox8 = new javax.swing.JCheckBox();
        jCheckBox9 = new javax.swing.JCheckBox();
        jCheckBox10 = new javax.swing.JCheckBox();
        jCheckBox11 = new javax.swing.JCheckBox();
        jCheckBox12 = new javax.swing.JCheckBox();
        jCheckBox13 = new javax.swing.JCheckBox();
        jCheckBox14 = new javax.swing.JCheckBox();
        jCheckBox15 = new javax.swing.JCheckBox();
        jCheckBox16 = new javax.swing.JCheckBox();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new java.awt.FlowLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("TELUQ RSS"));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setLayout(new java.awt.GridLayout(1, 0));
        jPanel1.add(jPanel2, java.awt.BorderLayout.NORTH);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTabbedPane1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTabbedPane1.setPreferredSize(new java.awt.Dimension(1205, 668));

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("URL: https://www.teluq.ca/site/infos/rss/communiques.php");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jLabel1.setPreferredSize(new java.awt.Dimension(290, 50));
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 388, 30));

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 1200, 40));

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 1200, 40));

        jButton3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 1200, 40));

        jButton4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 1200, 40));

        jButton5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 1200, 40));

        jButton6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 1200, 40));

        jButton7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 1200, 40));

        jButton8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 1200, 40));

        jButton9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton9.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 370, 1200, 40));

        jButton10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 410, 1200, 40));

        jButton11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton11.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, 1200, 40));

        jButton12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton12.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 490, 1200, 40));

        jButton13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 530, 1200, 40));

        jButton40.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton40.setText("Importer");
        jButton40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton40ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton40, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 140, 30));

        jButton14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton14.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 570, 1200, 40));

        jButton15.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 610, 1200, 40));

        jButton16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton16.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 650, 1200, 40));

        jTabbedPane1.addTab("                     Consulter sur internet                    ", jPanel4);

        jPanel5.setLayout(new java.awt.BorderLayout());

        jPanel10.setPreferredSize(new java.awt.Dimension(1100, 60));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Aucun fichier selectionné");
        jPanel10.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 20, -1, -1));

        jButton19.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton19.setText("Choisir un fichier");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 540, 40));

        jPanel5.add(jPanel10, java.awt.BorderLayout.NORTH);

        jTabbedPane2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTabbedPane2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane2MouseClicked(evt);
            }
        });

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel6.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 410, 1200, 190));

        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton20.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton20.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1190, 25));

        jButton21.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton21.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 25, 1190, 25));

        jButton22.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton22.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton22, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 1190, 25));

        jButton23.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton23.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton23, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 75, 1190, 25));

        jButton24.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton24.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton24, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 1190, 25));

        jButton25.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton25.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 125, 1190, 25));

        jButton26.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton26.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 1190, 25));

        jButton27.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton27.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton27, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 175, 1190, 25));

        jButton28.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton28.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 1190, 25));

        jButton29.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton29.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton29, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 225, 1190, 25));

        jButton30.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton30.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton30, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 1190, 25));

        jButton31.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton31.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 275, 1190, 25));

        jButton32.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton32.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton32ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton32, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 1190, 25));

        jButton33.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton33.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton33ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton33, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 325, 1190, 25));

        jButton34.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton34.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton34, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 350, 1190, 25));

        jButton35.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton35.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton35ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton35, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 375, 1190, 25));

        jScrollPane2.setViewportView(jPanel11);

        jPanel6.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 410));

        jTabbedPane2.addTab("          Visualiser un événement          ", jPanel6);

        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel23.setText("Titre:");
        jPanel7.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 130, 30));

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel24.setText("Lien:");
        jPanel7.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 130, 30));

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel25.setText("Date de publication:");
        jPanel7.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 130, 30));

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel26.setText("Description:");
        jPanel7.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 130, 30));

        jTextField5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField5MouseClicked(evt);
            }
        });
        jPanel7.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 1040, 30));

        jTextField6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField6MouseClicked(evt);
            }
        });
        jPanel7.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 1040, 30));

        jTextField7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField7MouseClicked(evt);
            }
        });
        jPanel7.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 1040, 30));

        jTextField8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField8MouseClicked(evt);
            }
        });
        jPanel7.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 1040, 30));

        jButton38.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton38.setText("Enregistrer au fichier");
        jButton38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton38ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton38, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, 370, 90));

        jButton39.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton39.setText("Annuler la dernière modification");
        jButton39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton39ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton39, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 270, 370, 90));

        jLabel27.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(0, 153, 51));
        jPanel7.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 460, 60));

        jTextArea2.setColumns(20);
        jTextArea2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextArea2.setRows(5);
        jScrollPane3.setViewportView(jTextArea2);

        jPanel7.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, 1180, 160));

        jLabel29.setText("Événement ajouté:");
        jPanel7.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 340, 30));

        jTabbedPane2.addTab("          Ajouter un événement          ", jPanel7);

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jComboBox1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBox1.setMaximumRowCount(20);
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "" }));
        jComboBox1.setPreferredSize(new java.awt.Dimension(63, 30));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel8.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1190, 50));

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel19.setText("Titre:");
        jPanel8.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 130, 30));

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel20.setText("Lien:");
        jPanel8.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 130, 30));

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel21.setText("Date de publication:");
        jPanel8.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 130, 30));

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel22.setText("Description:");
        jPanel8.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 130, 30));

        jTextField1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField1MouseClicked(evt);
            }
        });
        jPanel8.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 1040, 30));

        jTextField2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField2MouseClicked(evt);
            }
        });
        jPanel8.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 140, 1040, 30));

        jTextField3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField3MouseClicked(evt);
            }
        });
        jPanel8.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 1040, 30));

        jTextField4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextField4MouseClicked(evt);
            }
        });
        jPanel8.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 1040, 30));

        jButton36.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton36.setText("Enregistrer au fichier");
        jButton36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton36ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton36, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, 370, 90));

        jButton37.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton37.setText("Annuler la dernière modification");
        jButton37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton37ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton37, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 270, 370, 90));

        jLabel28.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 153, 51));
        jPanel8.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, 460, 30));

        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextArea3.setRows(5);
        jScrollPane4.setViewportView(jTextArea3);

        jPanel8.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, 1180, 160));

        jLabel30.setText("Événement modifié :");
        jPanel8.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 400, 360, 30));

        jTabbedPane2.addTab("          Modifier un événement          ", jPanel8);

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jCheckBox1.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox1.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox1.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        jCheckBox2.setInheritsPopupMenu(true);
        jCheckBox2.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox2.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox2.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

        jCheckBox3.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox3.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox3.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, -1, -1));

        jCheckBox4.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox4.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox4.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));

        jCheckBox5.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox5.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox5.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        jCheckBox6.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox6.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox6.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, -1, -1));

        jCheckBox7.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox7.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox7.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        jCheckBox8.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox8.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox8.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, -1, -1));

        jCheckBox9.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox9.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox9.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, -1, -1));

        jCheckBox10.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox10.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox10.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, -1, -1));

        jCheckBox11.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox11.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox11.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, -1, -1));

        jCheckBox12.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox12.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox12.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, -1, -1));

        jCheckBox13.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox13.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox13.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, -1, -1));

        jCheckBox14.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox14.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox14.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, -1, -1));

        jCheckBox15.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox15.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox15.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 440, -1, -1));

        jCheckBox16.setMaximumSize(new java.awt.Dimension(25, 25));
        jCheckBox16.setMinimumSize(new java.awt.Dimension(25, 25));
        jCheckBox16.setPreferredSize(new java.awt.Dimension(25, 25));
        jPanel9.add(jCheckBox16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 470, -1, -1));

        jButton17.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton17.setText("Enregistrer au fichier");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 520, 370, 70));

        jButton18.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton18.setText("Annuler la dernière modification");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 520, 370, 70));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 1140, 25));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 1140, 25));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 1140, 25));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 1140, 25));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 1140, 25));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 1140, 25));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 1140, 25));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 1140, 25));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 1140, 25));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 1140, 25));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, 1140, 25));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 1140, 25));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, 1140, 25));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 1140, 25));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 440, 1140, 25));

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel9.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 470, 1140, 25));

        jTabbedPane2.addTab("          Retirer un événement          ", jPanel9);

        jPanel5.add(jTabbedPane2, java.awt.BorderLayout.CENTER);

        jTabbedPane1.addTab("                              Fichier                             ", jPanel5);

        jPanel3.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 720));

        jPanel1.add(jPanel3, java.awt.BorderLayout.CENTER);

        getContentPane().add(jPanel1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        consulterURL(0); // Boutons de l'onglet Consulter sur internet.     
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        consulterURL(1);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        consulterURL(2);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        consulterURL(3);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        consulterURL(4);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        consulterURL(5);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        consulterURL(6);
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        consulterURL(7);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        consulterURL(8);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        consulterURL(9);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        consulterURL(10);
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        consulterURL(11);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        consulterURL(12);
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        consulterURL(13);
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        consulterURL(14);
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        consulterURL(15);
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        
        // Bouton "Choisir un fichier" de l'onglet Fichier.
       
        // Choix du fichier avec le jFileChooser.
        jFileChooser1.setVisible(true);
        int returnVal = jFileChooser1.showOpenDialog(this);
        
        if (returnVal == jFileChooser1.APPROVE_OPTION) {
            File file = jFileChooser1.getSelectedFile();
            if(file.getName().endsWith(".xml")){ // Pour fichiers XML seulement.
                String fichierXML = new String(file.getPath()); 
                jLabel2.setText(fichierXML); // Affiche le fichier dans lequel on travaille.
               
                path.setDocument(controller.getPathDocument(fichierXML)); //Controller charge le modèle.
                fichier = path.getListe(); // La vue récupère les données du modèle.
               
                // Modification de la vue.
                jLabel27.setText(""); // Retire les notifications.
                jLabel28.setText("");
                setVisualiser();
                setRetirer();
                setModifier();
                setModifierChamps(); 
                
                controller.docList.clear(); // Vide la liste des modifications.
                controller.docCompteur = 0; // Réinitialisation du compteur de modifications.
                jTextArea1.setText(""); // Retire l'information noeud du jTextArea de l'onglet Visualiser un événement.
                jTextArea2.setText(""); // Retire l'information noeud du jTextArea de l'onglet Ajouter un événement.
                jTextArea3.setText(""); // Même chose pour l'onglet Modifier un événement.
                evenementOff();         // Masque les deux jTextArea et jLabels des onglets Ajouter et Modifier.
            }
        } 
            
        else{ // Message d'erreur si l'utilisateur choisi un fichier qui n'est pas au format XML.
            jOptionPane1.showMessageDialog(null, "SVP choisir un fichier avec l'extension .xml");   
        }     
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        setVisualiserTexteArea(0); // Boutons de l'onglet Visualiser un événement.
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        setVisualiserTexteArea(1); // Affiche l'information du noeud item dans le jTextArea.
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
       setVisualiserTexteArea(2);
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        setVisualiserTexteArea(3);
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
       setVisualiserTexteArea(4);
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
        setVisualiserTexteArea(5);
    }//GEN-LAST:event_jButton25ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        setVisualiserTexteArea(6);
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
        setVisualiserTexteArea(7);
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        setVisualiserTexteArea(8);
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
        setVisualiserTexteArea(9);
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
        setVisualiserTexteArea(10);
    }//GEN-LAST:event_jButton30ActionPerformed

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
        setVisualiserTexteArea(11);
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed
        setVisualiserTexteArea(12);
    }//GEN-LAST:event_jButton32ActionPerformed

    private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed
        setVisualiserTexteArea(13);
    }//GEN-LAST:event_jButton33ActionPerformed

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
        setVisualiserTexteArea(14);
    }//GEN-LAST:event_jButton34ActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
        setVisualiserTexteArea(15);
    }//GEN-LAST:event_jButton35ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
      
      // Bouton Enregistrer au fichier de l'onglet Retirer un événement.
        
      // Message à l'utilisateur et vérification de la présence d'un fichier de travail. 
      if (jLabel2.getText() == "Aucun fichier selectionné") {
        jOptionPane1.showMessageDialog(null, "SVP choisir un fichier"); 
      }   
       
      // Si un fichier a été choisi, on enregistre les modifications.
      else {
        
        setEnregistrer();
        
        int compteur = 0;   // Pour coordonner le changement de positions lorsqu'un événement est
                            // retiré de "List fichier".

        // Retire les événements sélectionnés.
        if(jCheckBox1.isSelected()){
            fichier.remove(0-compteur);
            compteur++;
        }

        if(jCheckBox2.isSelected()){
            fichier.remove(1-compteur);
            compteur++;
        }

        if(jCheckBox3.isSelected()){
            fichier.remove(2-compteur);
            compteur++;
        }

        if(jCheckBox4.isSelected()){
            fichier.remove(3-compteur);
            compteur++;
        }

        if(jCheckBox5.isSelected()){
            fichier.remove(4-compteur);
            compteur++;
        }

        if(jCheckBox6.isSelected()){
            fichier.remove(5-compteur);
            compteur++;
        }

        if(jCheckBox7.isSelected()){
            fichier.remove(6-compteur);
            compteur++;
        }

        if(jCheckBox8.isSelected()){
            fichier.remove(7-compteur);
            compteur++;
        }

        if(jCheckBox9.isSelected()){
            fichier.remove(8-compteur);
            compteur++;
        }

        if(jCheckBox10.isSelected()){
            fichier.remove(9-compteur);
            compteur++;
        }

        if(jCheckBox11.isSelected()){
            fichier.remove(10-compteur);
            compteur++;
        }

        if(jCheckBox12.isSelected()){
            fichier.remove(11-compteur);
            compteur++;
        }

        if(jCheckBox13.isSelected()){
            fichier.remove(12-compteur);
            compteur++;
        }

        if(jCheckBox14.isSelected()){
            fichier.remove(13-compteur);
            compteur++;
        }

        if(jCheckBox15.isSelected()){
            fichier.remove(14-compteur);
            compteur++;
        }

        if(jCheckBox16.isSelected()){
            fichier.remove(15-compteur);
            compteur++;
        }
        
        // Demande au controlleur d'enregistrer le document du modèle au fichier dans lequel on travaille.
        controller.enregistrerFichier(path.getDocument(), jLabel2.getText());

        // Réinitialise la sélection des jCheckBox.
        jCheckBox1.setSelected(false);
        jCheckBox2.setSelected(false);
        jCheckBox3.setSelected(false);
        jCheckBox4.setSelected(false);
        jCheckBox5.setSelected(false);
        jCheckBox6.setSelected(false);
        jCheckBox7.setSelected(false);
        jCheckBox8.setSelected(false);
        jCheckBox9.setSelected(false);
        jCheckBox10.setSelected(false);
        jCheckBox11.setSelected(false);
        jCheckBox12.setSelected(false);
        jCheckBox13.setSelected(false);
        jCheckBox14.setSelected(false);
        jCheckBox15.setSelected(false);
        jCheckBox16.setSelected(false);
        
        // Mise-à-jour de la vue.
        setRetirer();
        setVisualiser();
        jTextArea1.setText("");
        setModifier();
        setModifierChamps();
      }
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        
      // Bouton Annuler la dernière modification de l'onglet Retirer un événement.
      
      // Message à l'utilisateur.
      if (jLabel2.getText() == "Aucun fichier selectionné") {
        jOptionPane1.showMessageDialog(null, "SVP choisir un fichier"); 
      }  
      
      // Si la liste des modifications est vide.
      else if (controller.docCompteur == 0){
            jOptionPane1.showMessageDialog(null, "Il n'y a aucune modification à annuler");
      }
      
      else {
        
        setAnnuler();  
        
        setModifierChamps();
        jTextArea1.setText("");
      }
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // Mise-à-jour des champs de l'onglet Modifier un événement lorsque l'utilisateur
        // choisi un nouvel événement dans le jComboBox.
        
        setModifierChamps();
        evenementOff(); // Masque le jTextArea et le jLabel comme rétroaction à l'utilisateur.
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
      
      // Bouton Enregistrer au fichier de l'onglet Modifier un événement.  
        
      // Message à l'utilisateur et vérification de la présence d'un fichier de travail.
      if (jLabel2.getText() == "Aucun fichier selectionné") {
        jOptionPane1.showMessageDialog(null, "SVP choisir un fichier"); 
      }   
      
      // Si un fichier est présent, on apporte les modifications.
      else {
        
        int selection = jComboBox1.getSelectedIndex(); // Mise en mémoire de la position de l'événement choisi.

        setEnregistrer();

        // Modification des éléments du noeud item dans "List fichier".
        ((Element) fichier.get(jComboBox1.getSelectedIndex())).getChild("title").setText(jTextField1.getText());
        ((Element) fichier.get(jComboBox1.getSelectedIndex())).getChild("link").setText(jTextField2.getText());
        ((Element) fichier.get(jComboBox1.getSelectedIndex())).getChild("guid").setText(jTextField2.getText());
        ((Element) fichier.get(jComboBox1.getSelectedIndex())).getChild("pubDate").setText(jTextField3.getText());
        ((Element) fichier.get(jComboBox1.getSelectedIndex())).getChild("description").setText(jTextField4.getText());

        controller.enregistrerFichier(path.getDocument(), jLabel2.getText());
        
        // Mise-à-jour de la vue.
        jLabel28.setText(messageModifieEvenement); // Notification Observer.
        setRetirer();
        setVisualiser();
        jTextArea1.setText(new XMLOutputter().outputString((Element) fichier.get(selection))); // Affiche le noeud modifié dans l'onglet Visualiser un événement.
        setModifier();
        jComboBox1.setSelectedIndex(selection); // Recharge l'information de l'onglet.
        setModifierChamps();                    // Réinitialise les champs.
        evenementOn();                          // Affiche le jLabel et le jTextArea de l'onglet.
        jTextArea3.setText(new XMLOutputter().outputString((Element) fichier.get(selection))); // Affiche l'information du noeud.
      }
    }//GEN-LAST:event_jButton36ActionPerformed

    private void jButton37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton37ActionPerformed
      
      // Bouton Annuler la dernière modification de l'onglet Modifier un événement.  
        
      int selection = jComboBox1.getSelectedIndex();  
        
      if (jLabel2.getText() == "Aucun fichier selectionné") {
        jOptionPane1.showMessageDialog(null, "SVP choisir un fichier"); 
      }  
      
      else if (controller.docCompteur == 0){
            jOptionPane1.showMessageDialog(null, "Il n'y a aucune modification à annuler");
      }
      
      else {

        setAnnuler();
        
        // Mise-à-jour de la vue.
        jTextArea1.setText(new XMLOutputter().outputString((Element) fichier.get(selection)));
        jComboBox1.setSelectedIndex(selection);
        setModifierChamps();
        jLabel28.setText(messageAnnulerEvenement); // Notification Observer.
      }
    }//GEN-LAST:event_jButton37ActionPerformed

    private void jButton38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton38ActionPerformed
      
      // Bouton Enregistrer au fichier de l'onglet Ajouter un événement.  
        
      if (jLabel2.getText() == "Aucun fichier selectionné") {
        jOptionPane1.showMessageDialog(null, "SVP choisir un fichier"); 
      }  
      
      else {
        
        setEnregistrer();
        
        // Ajout du nouveau noeud item dans "List fichier".
        fichier.add(0, new Element("item").addContent(new Element("title").setText(jTextField5.getText()))
                .addContent(new Element("link").setText(jTextField6.getText()))
                .addContent(new Element("guid").setText(jTextField6.getText()))
                .addContent(new Element("pubDate").setText(jTextField7.getText()))
                .addContent(new Element("description").setText(jTextField8.getText())));
        
        controller.enregistrerFichier(path.getDocument(), jLabel2.getText());

        jLabel27.setText(messageAjoutEvenement); // Notification Observer.
        jTextField5.setText(""); // Efface les champs pour améliorer la rétroaction à l'utilisateur.
        jTextField6.setText("");
        jTextField7.setText("");
        jTextField8.setText("");
        
        // Pour corriger l'affichage du noeud dans l'onglet Visualiser un événement.
        // Sans ce bloc, le noeud est affiché comme une ligne de texte continue au lieu d'afficher 
        // un élément par ligne.
        path.setDocument(controller.getPathDocument(jLabel2.getText()));
        fichier = path.getListe();
        
        // Mise-à-jour de la vue.
        setRetirer();
        setVisualiser();
        jTextArea1.setText(new XMLOutputter().outputString((Element) fichier.get(0))); // jTextArea de l'onglet Visualiser un événement.
        setModifier();
        setModifierChamps();
        evenementOn(); // Affiche le jLabel et jTextArea de l'onglet (Patron Composite)
        jTextArea2.setText(new XMLOutputter().outputString((Element) fichier.get(0)));
      }
    }//GEN-LAST:event_jButton38ActionPerformed

    private void jButton39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton39ActionPerformed
      
      // Bouton Annuler la dernière modification de l'onglet Ajouter un événement.  
        
      if (jLabel2.getText() == "Aucun fichier selectionné") {
        jOptionPane1.showMessageDialog(null, "SVP choisir un fichier"); 
      }  
      
      else if (controller.docCompteur == 0){
            jOptionPane1.showMessageDialog(null, "Il n'y a aucune modification à annuler");
      }
      
      else {
        
        setAnnuler();
     
        // Mise-à-jour de la vue.
        jLabel27.setText(messageAnnulerEvenement); // Notification Observer.
        jTextField5.setText("");
        jTextField6.setText("");
        jTextField7.setText("");
        jTextField8.setText("");
        jTextArea1.setText(""); // Onglet Visualiser un événement.
        setModifierChamps();
      }
    }//GEN-LAST:event_jButton39ActionPerformed

    private void jTabbedPane2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane2MouseClicked
        
        // Mise-à-jour de la vue lors de l'entrée dans un onglet (mode Fichier).
        
        jLabel27.setText("");
        jLabel28.setText("");
        evenementOff();
        controller.docList.clear(); // Pour éviter d'annuler une modification faite dans un autre onglet.
        controller.docCompteur = 0;
    }//GEN-LAST:event_jTabbedPane2MouseClicked

    private void jButton40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton40ActionPerformed
        
        // Bouton Importer de l'onglet Consulter sur internet.
        
        jFileChooser1.setVisible(true);
        int returnVal = jFileChooser1.showSaveDialog(this);
        if (returnVal == jFileChooser1.APPROVE_OPTION) {
            
            // Message à l'utilisateur pour éviter d'écraser un fichier existant ou d'enregistrer sous un mauvais format.
            if((jFileChooser1.getSelectedFile().exists()) || (!jFileChooser1.getSelectedFile().getName().endsWith(".xml"))) { 
            
                jOptionPane1.showMessageDialog(null, "SVP choisir un nom de fichier inexistant et utiliser l'extension .xml");   
            }
            
            else {
                
                File file = jFileChooser1.getSelectedFile();


                url.setDocument(controller.getUrlDocument());
                controller.enregistrerFichier(url.getDocument(), file.getAbsolutePath()); // Demande au controlleur d'enregistrer le fichier.

                // Chargement du fichier créé dans l'onglet Fichier et mise-à-jour de la vue.
                String fichierXML = new String(file.getPath());
                jLabel2.setText(fichierXML);
                path.setDocument(controller.getPathDocument(jLabel2.getText()));
                fichier = path.getListe();
                jLabel27.setText("");
                jLabel28.setText("");
                jTextArea1.setText("");
                jTextArea2.setText("");
                jTextArea3.setText("");
                evenementOff();
                setVisualiser();
                setRetirer();
                setModifier();
                setModifierChamps();
                controller.docList.clear();
                controller.docCompteur = 0;
            }
        }
    }//GEN-LAST:event_jButton40ActionPerformed

    private void jTextField1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField1MouseClicked
        jLabel28.setText(""); // Efface la notification lorsque l'utilisateur appuie sur un champ.
    }//GEN-LAST:event_jTextField1MouseClicked

    private void jTextField2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField2MouseClicked
        jLabel28.setText(""); // Onglet Modifier un événement.
    }//GEN-LAST:event_jTextField2MouseClicked

    private void jTextField3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField3MouseClicked
        jLabel28.setText("");
    }//GEN-LAST:event_jTextField3MouseClicked

    private void jTextField4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField4MouseClicked
        jLabel28.setText("");
    }//GEN-LAST:event_jTextField4MouseClicked

    private void jTextField5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField5MouseClicked
        jLabel27.setText(""); // Efface la notification lorsque l'utilisateur appuie sur un champ.
    }//GEN-LAST:event_jTextField5MouseClicked

    private void jTextField6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField6MouseClicked
        jLabel27.setText(""); // Onglet Ajouter un événement.
    }//GEN-LAST:event_jTextField6MouseClicked

    private void jTextField7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField7MouseClicked
        jLabel27.setText("");
    }//GEN-LAST:event_jTextField7MouseClicked

    private void jTextField8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField8MouseClicked
        jLabel27.setText("");
    }//GEN-LAST:event_jTextField8MouseClicked
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Bouton.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Bouton.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Bouton.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Bouton.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Bouton().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton40;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox10;
    private javax.swing.JCheckBox jCheckBox11;
    private javax.swing.JCheckBox jCheckBox12;
    private javax.swing.JCheckBox jCheckBox13;
    private javax.swing.JCheckBox jCheckBox14;
    private javax.swing.JCheckBox jCheckBox15;
    private javax.swing.JCheckBox jCheckBox16;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JCheckBox jCheckBox9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    // End of variables declaration//GEN-END:variables

}
